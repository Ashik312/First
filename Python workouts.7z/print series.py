x=int(input("Enter the start value : "))
y=int(input("Enter the end value : "))
z=int(input("Enter the common difference : "))
i=x
if i>=y:
    while i>=y:
        print(i,end=" ")
        i-=z
elif i<=y:
    while i<=y:
        print(i,end=" ")
        i+=z
else:
    print("INVALID ENTRY")