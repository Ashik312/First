l=[]
num=6
i=1
while i<=10:
    l.append(num*i)
    i+=1
print(l)    