def sample(x):
    for i in range(1,x):
        for j in range(1,i+1):
            print(j,end=" ")
        print()
sample(x=int(input("enter a limit :")))