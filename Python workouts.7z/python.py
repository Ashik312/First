# a=2
# b=4
# c=a+b
# print(c)
# a=int(input("Enter number one : "))
# b=int(input("Enter number two : "))
# c=a*b
# print("Product of two numbers : ",c)
# import math
# print(math.sqrt(16))
# a="Ashik "
# b=" is a "
# c=" goodboy"
# print(a+b+c)
# x=str(5)
# y=float(3)
# print(type(x))
