age=int(input("Enter your age : "))
if 18<=age:
    print("You are eligible to vote")
else:
    print("You are not eligible to vote")