class samp:
    def __init__(self):
        self.d=6
        self.c=10
    def add(self,a,b):
        print(self.a+self. b)
    def add(self):
        print(self.d+self.c)
obj=samp()
obj.add(5,5)