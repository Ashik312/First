dict1={"number1":2,"number2":22,"number3":5}
l1=dict1.values()
if 22 in l1:
    print("Value Exists!")
else:
    print("Value does't Exist!")