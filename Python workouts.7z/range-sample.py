for i in range(0,11):
    print(i)