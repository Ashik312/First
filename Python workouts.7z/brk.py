for i in "hello":
    if i=="e":
        break
    print(i)