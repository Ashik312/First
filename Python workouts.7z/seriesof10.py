i=10
while i<=100:
    print(i)
    i+=10