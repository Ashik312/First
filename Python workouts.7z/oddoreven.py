x=int(input("Enter number 1 : "))
y=int(input("Enter number 2 : "))
if x%2==0 and y%2==0:
    print("Sum = ",x+y)
elif x%2==1 and y%2==1:
    print("product = ",x*y)
else:
    print("0")
