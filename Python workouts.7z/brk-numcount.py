text="8Hello95python123"
count=0
s=""
for i in text:
    if i.isdigit():
        s+=i
        count+=1
        if count==3:
            break
print(s)
print(count)
