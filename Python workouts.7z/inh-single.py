class person:
    def __init__(self):
        self.name="Alex"
        self.age="20"
        print("Hello")
class student(person):
    def __init__(self):
        super().__init__()
        print(self.name,self.age)
        print("I am inevitable 😎")
stud=student()