l1=['rock','paper','scissors'];print(l1)
user=str(input("Enter your choice : "))
import random
com=(random.choice(l1))
print(com)
if user==com:
    print("The game is a tie")
elif user==l1[0] and com==l1[2]:
    print("user wins")
elif user==l1[1] and com==l1[0]:
    print("user wins")
elif user==l1[2] and com==l1[1]:
    print("user wins")
else:
    print("computer wins")