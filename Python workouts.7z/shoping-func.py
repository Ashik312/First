dict1={"SHIRT":699,"TSHIRT":399,"JEANS":1299,"WATCH":3999};i=0;l=[];ref=0;su=0
while i!=1:
    print("\n ITEMS\n ~~~~~\n\n* SHIRT\n* TSHIRT\n* JEANS\n* WATCH\n\n* EXIT\n")
    ch=input("please select Your choice from the option :")
    if ch=="EXIT":
        print("Selected items : ",l)
        print("Total amount : ",su)
        i=1
    else:
        if ch=="SHIRT" or ch=="TSHIRT" or ch=="JEANS" or ch=="WATCH":
            l.append(ch)
            ref=dict1[ch]
            su=su+ref
        else:
            print("INVALID ENTRY")