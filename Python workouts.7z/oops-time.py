class Tym:
    def __init__(self,hours,minutes):
        self.hours=hours
        self.minutes=minutes
    def addtime(self):
        hour1=int(input("Enter hour in 1st tym : "))
        minute1=int(input("Enter minutes in 1st tym : "))
        hour2=int(input("Enter hour in 2nd tym : "))
        minute2=int(input("Enter minutes in 2nd tym : "))
        Tot=(minute1+minute2)//60
        Tothour=(hour1+hour2+Tot)
        Totmint=(minute1+minute2)%60
        print("Added Time :",Tothour,"hours",Totmint,"minutes")
    def totminute(self):
        totmin=(self.hours*60)+self.minutes
        print("Total minutes : ",totmin)
    def displaytym(self):
        print(self.hours,"Hours",self.minutes,"Minutes")
hr=int(input("Enter hour in tym : "))
min=int(input("Enter minutes in tym : "))
obj=Tym(hr,min);obj.displaytym();obj.totminute();obj.addtime()

