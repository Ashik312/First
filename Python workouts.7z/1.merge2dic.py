d1={"messi":10,"dybala":8}
d2={"rono":7,"bruno":6}
d1.update(d2)
print(d1)
print(d2)
print(d1.keys())