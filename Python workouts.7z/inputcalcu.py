a=int(input("Enter 1st Input : "))
b=int(input("Enter 2nd input : "))
print("+,-,*️,/,**,//,%")
op=input("Select one of any operator from above : ")
if op=='+':
    print("Sum = ",a+b)
elif op=='-':
    print("Substractor = ",a-b)
elif op=='*':
    print("Product = ",a*b)
elif op=='/':
    print("Divide = ",a/b)
elif op=='**':
    print("Exponent = ",a**b)
elif op=='//':
    print("Divide without fraction = ",a//b)
elif op=='%':
    print("Modules = ",a%b)
else:
    print("Invalid operator!")

