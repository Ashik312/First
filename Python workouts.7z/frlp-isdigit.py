l=['abc819','nig97','apb83d']
s=[]
for i in l:
    for j in i:
        if j.isdigit():
            s.append(j)
print(s)