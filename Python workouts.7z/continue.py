# for i in range(0,6):
#     print("hello")
#     if i==3:
#         break
#     print("hi")
n=5
i=0
while i<=n:
    
    i+=1
    if i==3:
        continue
    print(i)

