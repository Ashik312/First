# from tkinter import*
# from PIL import ImageTk,Image
# window = Tk()
# window.title("OOSU")
# window.geometry('350x450')
# img=ImageTk.PhotoImage(Image.open("OIP.jpg"))
# btn=Button(window,image=img).grid(row=2,column=0)
# mainloop()
 

    #    EX

# from tkinter import *
# from PIL import ImageTk,Image
# root = Tk()
# def new():
#     newWindow = Toplevel(root)
#     newWindow.title("New Window")
#     newWindow.geometry("400x300")
#     Button(newWindow, text = 'Click Me !', image = img,command=new).pack(side = TOP)
# Label(root, text = 'GeeksforGeeks', font =('Verdana', 15)).pack(side = TOP, pady = 10)
# img=ImageTk.PhotoImage(Image.open("OIP.jpg"))
# Button(root, text = 'Click Me !', image = img,command=new).pack(side = TOP)

# mainloop()


# from tkinter import*
# from tkinter.ttk import*
# root = Tk()
# root.geometry('150x150')
# btn = Button(root,text='SHOTTE')
# btn.pack(side = 'top')
# root.mainloop()



from tkinter import *
from tkinter.ttk import *
root = Tk()
style = Style()
style.configure('W.TButton', font =
			('calibri', 18, 'bold'),
				foreground = 'red')
btn1 = Button(root, text = '😡 !',
				style = 'W.TButton')
btn1.grid(row = 0, column =2, padx = 50)
btn2 = Button(root, text = '😁', command = None)
btn2.grid(row = 1, column = 2, pady = 10, padx = 50)


C = Canvas(root, bg="yellow",height=250, width=300)
line = C.create_line(108, 120,320, 40,fill="green")
arc = C.create_arc(180, 150, 80,
                   210, start=0,
                   extent=220,
                   fill="red")
oval = C.create_oval(80, 30, 140,
                                        150,
                                        fill="blue")
C.grid(row=2,column=0)
root.mainloop()
