# text='python is interpreted'
# l=text.split()
# s1=''.join(sorted(l[0]))
# s2=''.join(sorted(l[1]))
# s3=''.join(sorted(l[2]))
# print(s1,s2,s3)


text='python is interpreted'
l=text.split()
s=''
for i in l:
    s+=''.join(sorted(i))+' '
print(s)
    
