# class cat:
#     def puzz(self):
#         print("I am a cat")
#         print("Do you want to give me a name : ")
# class dog:
#     def dogs(self,name):
#         print("I am a Dog,my name is ",name)
# class pet(cat,dog):
#     def __init__(self):
#         super().puzz()
#         super().dogs("Alen")
#         print("We are under pet category")
# obj=pet()

class film:
    def Tamil(self):
        print("ASURAN")
        print("MAYAVAN")
    def Hindi(self):
        print("YE JAWANI HE DIWANI")
class film1:
    def English(self):
        print("FORD VS FERARI")
class films(film,film1):
    def __init__(self):
        super().Hindi()
        super().English()
        print("ADI KAPYARE KOOTAMANI")
class padam(films):
    def __init__(self):
        super().__init__()
        super().Tamil()
obj=padam()
    
