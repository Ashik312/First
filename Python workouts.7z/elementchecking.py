l1=[1,4,3,2,8,6]
l2=[3,5,8,9,10]
x=int(input("Enter a value to be checked : "))
if x in l1:
    print("value is in the list1",l1)
elif x in l2:
    print("value is in the list2",l2)
else:
    print("value not found ")        
    