print("Welcome To Quiz!!")
a=input("Are you ready?(yes/no):")
if a=="yes":
    pass