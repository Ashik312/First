unit=int(input("Enter unit of Electricity used :"))
if unit>200:
    a=unit-200
    b=100*5
    c=a*10
    seccash=b+c
    print(seccash,"/- is to be paid")
elif unit>100:
    x=unit-100
    cash=x*5
    print(cash,"/- is to be paid")
else:
    print("No money needed to be paid")