lim=int(input("Enter number of elements :"))
i=0
l1=[]
l2=[]
print("Enter Elements :")
while i<=lim-1:
    l1.append(int(input()))
    i+=1
i=0
while i<=lim-1:
    if l1[i] not in l2:
        l2.append(l1[i])
    i+=1
print("Entered List : ",l1)
print("Unique List : ",l2)