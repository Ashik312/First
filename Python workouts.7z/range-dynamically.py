n=int(input("Enter Limit : "))
for i in range(0,n+1):
    print(i)