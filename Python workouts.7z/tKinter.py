# import tkinter
# window = tkinter.Tk()
# label = tkinter.Label(window,text = "Hello ").pack()
# window.mainloop()

# from tkinter import*
# master = Tk()
# Label(master,text="First").grid(row=4,column=3)
# Label(master,text="second").grid(row=5,column=4)
# e1 = Entry(master)
# e2 = Entry(master)
# mainloop()


from tkinter import*
master = Tk()

mainloop()