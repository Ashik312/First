em=["Happy","Sad","Angry"]
print(em)
md=input("Enter your mood as in the above:")
if md=="Happy":
    print("😁")
elif md=="Sad":
    print("😔")
elif md=="Angry":
    print("😡")
else:
    print("🤫")

    