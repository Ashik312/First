n=100
i=1
while i<=n:
    if i%2==0 and i%5!=0:
        print(i)
    i+=1

    