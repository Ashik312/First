mark=int(input("Enter mark :"))
if mark>100:
    print("100 is the limit")
elif mark>=90:
    print("A grade")
elif mark>=80:
    print("B grade")
elif mark>=60:
    print("C grade")
else:
    print("Better luck next time")
    