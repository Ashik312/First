dict1={"apple":33,"banana":34,"grape":55,"orange":68}
for i in dict1.values():
    if i%2!=0:
        print(i)

# dict1={"apple":33,"banana":34,"grape":55,"orange":68}
# count=0
# for i in dict1.keys():
#     for j in i:
#         if j=="a":
#             count+=1
# print(count)