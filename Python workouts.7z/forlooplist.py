l=[10,20,15,35]
sum=0
for i in l:
    sum=sum+i
print(sum)