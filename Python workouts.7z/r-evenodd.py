l1=[]
l2=[]
for i in range(100,501):
    if i%2==0:
        l1.append(i)
    else:
        l2.append(i)
print(l1)
print(l2)