n=5
i=1
while i<=n:
    print(i**2)
    i+=1
# s=10
# i=2
# while i<=s:
#     print(i)
#     i+=2
