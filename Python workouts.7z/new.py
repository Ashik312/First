import random
l={"It is a fruit":"apple","It is a vehicle":"bike","It is a flower":"rose"}
vl=list(l.values())
kl=list(l.keys())
s2=""
s=random.choice(vl)
ind=vl.index(s)
le=len(s)
print(kl[ind])
for i in range(0,le):
    s2=s2+"_"
print(s2)
i=5
while i!=0:
    g=input("Guess the word : ")
    if len(g)==1:
        if g in s:
            j=0
            for j in range(len(s)):
                if g==s[j] and  s[j]!=s2[j]:
                    s2 = s2[:j] + g + s2[j + 1:]
                if j==len(s)-1:
                    print(s2)
                    print(i,"Chances Left !")
                if s2.isalpha():
                    print("Word Found 👌\n",s2)
                    break
                    
                else:
                    continue
        else:
            i=i-1
            print(i,"Chances Left !")
            if i==0:
                print("Your chances are over !!!")
    else:
        print("Enter only one letter")




# d={"It is a fruit":"apple","It is a vehicle":"bike","It is a flower":"rose"}
# value=list(d.values())
# key=list(d.keys())
# import random
# com = random.choice(value)
# comchoice=value.index(com)
# print("\n",key[comchoice])
# l=len(com)
# dash=(l*"_")
# print("\n",dash,"\n")
# i=6
# while i!=0:
#     user=input("GUESS THE WORD : ")
#     if len(user)==1:
#         if user in com:
#             posi=com.index(user)
#             dash=dash[:posi]+user+dash[posi+1:]
#             print(dash)
#             if dash.isalpha():
#                 print("EUREKKA 👌")
#                 break
#             print(i,"REMAINING")
#         else:
#             i=i-1
#             print(i,"REMAINING")
#             if i==0:
#                 print("NO MORE CHANCES LEFT FOR U POOR SOUL 🤫")
#     else:
#         print("ONLY ONE LETTER PLEASE ")
    

