# n=int(input("Enter a number : "))
# for i in range(1,n+1,2):
#     for j in range(n-i):
#         print(" ",end="")
#     for j in range(1,i+1):
#         if j%2==1:
#             print("*",end=" ")
#         else:
#             print("A",end=" ")
#     print()

n=int(input("Enter a number : "))
i=0
while i<=n+1:
    j=1
    while  j<=n-i:
        print(" ",end="")
        j+=1
    j=1
    while j<=i+1:
        if j%2==1:
            print("*",end=" ")
        else:
            print("A",end=" ")
        j+=1
    print()
    i+=2