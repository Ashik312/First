i=10
while i>=1:
    print(i,end=" ")
    i-=1