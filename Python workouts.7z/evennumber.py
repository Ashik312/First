s1=int(input("Enter starting point : "))
s2=int(input("Enter ending point : "))
i=s1
while i<=s2:
    if i%2==0:
        print(i,end=" ")
    i+=1