x=int(input("Enter the limit : "))
i=1
while i<=x:
    print(i," = ",i**2)
    i+=1