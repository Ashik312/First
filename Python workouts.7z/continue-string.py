s=[]
n="ashik"
for i in n:
    if i=="h":
        continue
    s.append(i)
print("".join(s))