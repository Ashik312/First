class samp:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display(self):
        print("Name :",self.name)
        print("Age :",self.age)
obj1=samp("suni",34)
obj2=samp("alen",34)
obj1.display()