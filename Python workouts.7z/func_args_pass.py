def sample(name):
    print(name)
sample('Anisha')
sample('suneesh')