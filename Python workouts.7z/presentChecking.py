def check(rnum):
    l1=[1,2,3,4,5,7,8,9,10,11,12,13,15,18,19,20,21]
    if rnum<=0:
        print("invalid rollno")
    else:
        if rnum in l1:
            print("present")
        else:
            print("Absent")
check(rnum=int(input("Enter Rollno :")))