from tkinter import*

window = Tk()
window.title("GUI")
window.geometry('350x450')

def add():
    r=(int(e1.get()) + int(e2.get()))
    e3.delete(0,END)
    e3.insert(END,r)

def sub():
    r=(int(e1.get())-int(e2.get()))
    e3.delete(0,END)
    e3.insert(END,r)

def div():
    r=(int(e1.get())/int(e2.get()))
    e3.delete(0,END)
    e3.insert(END,r)

def mul():
    r=int(e1.get())*int(e2.get())
    e3.delete(0,END)
    e3.insert(END,r)

n1=Label(window,text="num1").grid(row=0,column=0)

e1=Entry(window,width=20).grid(row=0,column=1,columnspan=4)

n2=Label(window,text="num2").grid(row=1,column=0)

e2=Entry(window,width=20).grid(row=1,column=1,columnspan=4)

btn1 = Button(window,padx=10,pady=4,text="+",command=add).grid(column=1,row=2)
btn2 = Button(window,padx=10,pady=4,text="-",command=sub).grid(column=2,row=2)
btn3 = Button(window,padx=10,pady=4,text="/",command=div).grid(column=3,row=2)
btn4 = Button(window,padx=10,pady=4,text="*",command=mul).grid(column=4,row=2)

n3=Label(window,text="Result").grid(row=3,column=0)

e3=Entry(window,width=5).grid(row=3,column=1)
mainloop()