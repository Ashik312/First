class bank:
    def __init__(self,name,age,phno):
        self.name=name
        self.age=age
        self.phno=phno
        self.AVL_BALANCE=0
    def per_details(self):
        print("Account holder : ",self.name)
        print("Age : ",self.age)
        print("Phone number : ",self.phno)
    def bank_details(self):
        self.IFSC_CODE="SBIN0246876"
        self.ACCNT_NO="059065557186"
        self.AVL_BALANCE=25350.24
    def deppo(self):
        self.deposit=int(input("Enter the amount to be incerted : "))
        print("Amount successfully deposited ")
        self.AVL_BALANCE=self.AVL_BALANCE+self.deposit
    def wid(self):
        self.withdraw=int(input("Enter the amount to be withdrawed : "))
        print("Amount successfully withdrawed ")
        self.AVL_BALANCE-=self.withdraw
    def T_bal(self):
        print(self.AVL_BALANCE)
name=input("Enter Name : ")
age=input("Enter Age : ")
phno=input("Enter Phone number : ")
obj=bank(name,age,phno)
obj.bank_details()
i=0
while i==0:
    ch=int(input("Choose operation\n1.Deposit\n2.Withdraw\n3.Check balance\n4.Exit\n"))
    if ch==1:
        obj.deppo()
    elif ch==2:
        obj.wid()
    elif ch==3:
        obj.T_bal()
    elif ch==4:
        break

