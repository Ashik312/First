# x=(input("Enter month(all characters must in caps) : "))
# if x=='JANUARY' or x=='MARCH' or x=='MAY' or x=='JULY' or x=='AUGUST' or x=='OCTOBER' or x=='DECEMBER':
#     print("31 days")
# elif x=='APRIL' or x=='JUNE' or x=='SEPTEMBER' or x=='NOVEMBER':
#     print("30 days")
# elif x=='FEBRUARY':
#     print("28 days")
# else:
#     print("Not a valid month")
# x=(input("Enter month(all characters must in caps) : "))
# l1=["JANUARY","MARCH","MAY","JULY","AUGUST","OCTOBER","DECEMBER"]
# l2=["APRIL","JUNE","SEPTEMBER","NOVEMBER"]
# l3=["FEBRUARY"]
# if x in l1:
#     print("31 days")
# elif x in l2:
#     print("30 days")
# elif x in l3:
#     print("28 days")
# else:
#     print("Not a valid month")
d={31:["january","may","march","july","august","october","december"],30:["april","june","september","november"],28:"february",29:"february"}
a=int(input("Enter total no:of days : "))
if a==31:
    print(d[31])
elif a==30:
    print(d[30])
elif a==28 or a==29:
    print(d[28])
else:
    print("Invalid input!")