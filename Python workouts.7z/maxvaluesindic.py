d1={"val1":200,"val2":15,"val3":255,"val4":25}
s=d1.values()
print(s)
print(min(s))
print(max(s))