Eng=int(input("Enter the mark of English : "))
Maths=int(input("Enter the mark of Maths : "))
Social=int(input("Enter the mark of Social : "))
Science=int(input("Enter the mark of Science : "))
Malayalam=int(input("Enter the mark of Malayalam : "))
sum=Eng+Maths+Social+Science+Malayalam
per=(sum/500)*100
if per>=90:
    print("Percentage = ",per,"%"," A+ grade ")
elif per>=85:
    print("Percentage = ",per,"%"," A grade ")
elif per>=80:
    print("Percentage = ",per,"%"," B+ grade ")
elif per>=75:
    print("Percentage = ",per,"%"," B grade ")
elif per>=70:
    print("Percentage = ",per,"%"," C+ grade ")
elif per>=65:
    print("Percentage = ",per,"%"," C grade ")
elif per>=60:
    print("Percentage = ",per,"%"," D+ grade ")
elif per>=50:
    print("Percentage = ",per,"%"," D grade ")
else:
    print("FAILED")