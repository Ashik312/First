class bank:
    def __init__(self):
        pass
    def per_details(self,name,branch):
        self.name=name
        self.branch=branch
    def bank_details(self,ifsc,acc,bal):
        self.IFSC_CODE=ifsc
        self.ACCNT_NO=acc
        self.AVL_BALANCE=bal
    def display(self):
        print("Name : ",self.name)
        print("IFSC code : ",self.IFSC_CODE)
        print("Branch : ",self.branch)
    def deppo(self):
        self.deposit=int(input("Enter the amount to be incerted : "))
        print("Amount successfully deposited ")
        self.AVL_BALANCE=self.AVL_BALANCE+self.deposit
    def wid(self):
        self.withdraw=int(input("Enter the amount to be withdrawed : "))
        print("Amount successfully withdrawed ")
        self.AVL_BALANCE-=self.withdraw
    def T_bal(self):
        print(self.AVL_BALANCE)
obj1=bank()
obj2=bank()
obj3=bank()
obj1.bank_details("SBI072356",2456784546,6250.00)
obj2.bank_details("SBI286546",3795481554,2300.00)
obj3.bank_details("SBI554987",3794225389,8370.00)
obj1.per_details("rahul","edavanakad")
obj2.per_details("sonare","varapuzha")
obj3.per_details("alen","kovalam")
l=[2456784546,3795481554,3794225389]
while True:
    acc=int(input("Enter account number :"))
    if acc in l:
        if obj1.ACCNT_NO==acc:
            obj1.display()
            while True:
                ch=int(input("Choose operation\n1.Deposit\n2.Withdraw\n3.Check balance\n4.Exit\n"))
                if ch==1:
                    obj1.deppo()
                elif ch==2:
                    obj1.wid()
                elif ch==3:
                    obj1.T_bal()
                elif ch==4:
                    break
        elif obj2.ACCNT_NO==acc:
             obj2.display()
             while True:
                ch=int(input("Choose operation\n1.Deposit\n2.Withdraw\n3.Check balance\n4.Exit\n"))
                if ch==1:
                    obj2.deppo()
                elif ch==2:
                    obj2.wid()
                elif ch==3:
                    obj2.T_bal()
                elif ch==4:
                    break
        elif obj3.ACCNT_NO==acc:
             obj3.display()
             while True:
                ch=int(input("Choose operation\n1.Deposit\n2.Withdraw\n3.Check balance\n4.Exit\n"))
                if ch==1:
                    obj3.deppo()
                elif ch==2:
                    obj3.wid()
                elif ch==3:
                    obj3.T_bal()
                elif ch==4:
                    break
        else:
            print("Invalid choice !")
    else:
        print("Invalid Account number !")
        ch3=int(input("Do you want to continue(1.yes/2.no)"))
        if ch3==1:
            continue
        else:
            break