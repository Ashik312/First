# try:
#     n=int(input("Enter 1st number : "))
#     n2=int(input("Enter 2nd number : "))
#     print(n/n2)
# except ZeroDivisionError:
#     print("Divion by Zero Occured!!!")

# try:
#     x='hello'+3000
# except TypeError:
#     print('Type error!!')

import os
try:
    f = input("Enter file name : ")
    if os.path.isfile(f):
        print("file exist")
    else:
        print("file do not exist")
except FileNotFoundError:
    print("Error:file not found")