num=int(input("Enter a limit : "))
j=0
k=1
l=0
print(j,k,end=" ")
for i in range(0,num-2):
    l=k
    k=j+k
    j=l
    print(k,end=" ")

