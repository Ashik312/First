x=int(input("Enter numbers : "))
