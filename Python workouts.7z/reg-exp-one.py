import re
txt="sat mat cat rat pat"
x = re.findall("[spr]at", txt)
print(x)


import re
txt="sat mat cat rat pat"
x = re.findall("[^spr]at", txt)
print(x)