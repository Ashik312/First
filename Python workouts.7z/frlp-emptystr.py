l=['abc819','nig97','apb83d']
s=''
for i in l:
    for j in i:
        if j.isalpha():
            s=s+j
print(s)