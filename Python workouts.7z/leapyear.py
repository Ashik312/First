year=int(input("Enter year : "))
if year%4==0:
    print("Year is Leap Year")
else:
    print("Year is not Leap Year")