def create():
    cr=str(input("Enter file name : "))
    f = open(cr, "x")
    f.close()
def read():
    rd=str(input("Enter file name : "))
    f = open(rd,"r")
    f.close()
def write():
    wr=str(input("Enter file name : "))
    f = open(wr,"w")
    wrt=str(input("Enter the content : "))
    f.write(wrt)
    f.close()
def delete():
    import os
    dl=str(input("Enter file name : "))
    if os.path.exists(dl):
        os.remove(dl)
    else:
        print("The file does not exist")
        
while 1==1:
    print("File Operations\n1.Create a file\n2.Read a file\n3.Write\n4.Delete\n5.Exit\n")
    ch=int(input("Choose one Operation :"))
    if ch==5:
        break
    elif ch==1:
        create()
    elif ch==2:
        read()
    elif ch==3:
        write()
    elif ch==4:
        delete()
    else:
        print("Enter a valid number🤫")