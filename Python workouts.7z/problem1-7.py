# i=1500
# while i<=2700:
#     if i%5==0 and i%7==0:
#         print(i,end=" ")
#     i+=1



l1=[1,2,3,4,5,6,7,8]
l2=[9,10,7,14,13,1,18]
m=[]
i=0
while i<=len(l1)-1:
    if l1[i]%2==1:
        m.append(l1[i])
    i+=1
i=0
while i<=len(l2)-1:
    if l2[i]%2==0:
        m.append(l2[i])
    i+=1
print(m)


# l1=[1,2,3,4,5,9,7,8]
# l2=[9,10,7,14,13,1,18]
# m=[]
# i=1
# s=len(l1)
# while i<=l1[:8]:
#     print(i)
#     i+=1

# m=
# l1=[1,2,3,4,5,6,7,8]
# i=1
# while i<=l1:
#     if l1[i]%2==1:
#         m.append(l1[i])
#     i+=1