#  * * * 
#  * *
#  *

# n=int(input("Enter the limit : "))
# for i in range(1,n+1):
#     for j in range(1,(n+2)-i):
#         print("*",end=" ")
#     print()

# for i in range(1,5):
#     print(" "*(5-i)," *"*i)




#   *
#  * *
# * * *

# n=int(input("Enter a number : "))
# for i in range(1,n+1):
#     for j in range(n-i):
#         print(" ",end="")
#     for j in range(1,i+1):
#         print("*",end=" ")
#     print()
i=1
while i<=5:
    j=5
    while j>i:
        print(" ",end="")
        j-=1
    j=0
    while j<=i-1:
        print("*",end=" ")
        j+=1
    i+=1
    print()





# * * *
#  * *
#   *

# n=int(input("Enter a number : "))
# for i in range(1,n+2):
#     for j in range(i-1):
#         print("*",end="")
#     for j in range(n+1-i):
#         print(" ",end=" ")
#     for j in range(i-1):
#         print("*",end="")
#     print()




#  * * *
#   * *
#    *
#   * *
#  * * *

# n=int(input("Enter a number : "))
# for i in range(1,n):
#     for j in range(i-1):
#         print("*",end=" ")
#     for j in range(n+1-i):
#         print(" ",end=" ")
#     print()
# for i in range(1,n+1):
#     for j in range(n-i):
#         print("*",end=" ")
#     for j in range(1,i+1):
#         print(" ",end=" ")
#     print()



#   * * * * *
#   *       *
#   *       *
#   * * * * *
 
# n=int(input("Enter a number : "))
# for i in range(1,n+1):
#     for j in range(1,n+1):
#         if i==1 or i==n:
#             print("*",end=" ")
#         else:
#             if j==1 or j==n:
#                 print("* ",end="")
#             else:
#                 print("  ",end="")
#     print()






#     *
#    * *
#   * * *
#  * * * *
#   * * *
#    * * 
#     *

# n=int(input("Enter a number : "))
# for i in range(1,n):
#     for j in range(n-i):
#         print(" ",end="")
#     for j in range(1,i+1):
#         print(chr(183),end=" ")
#     print()
# for i in range(1,n+1):
#     for j in range(i-1):
#         print(" ",end="")
#     for j in range((n+1)-i):
#         print(chr(183),end=" ")
#     print()

#  1
#  1 3
#  1 3 5

# # n=int(input("Number adi funde : "))
# for i in range(1,5):
#     k=1
#     for j in range(1,i+1): 
#         print(k,end=" ")
#         k+=2
#     print()




