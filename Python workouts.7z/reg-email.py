import re
txt=input("Enter your email : ")
x=re.findall("[a-z]+[_&]?[0-9]|[a-z]+@[a-z]+.[a-z]+",txt)
if x:
    print("valid email")
else:
    print("not valid")