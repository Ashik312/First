x=int(input("Enter a 3 digit number : "))
l_num=x%10
if l_num==0:
    print("zero can't be divided")
elif l_num%3==0:
    print("Divisible by 3")
elif l_num%7==0:
    print("Divisible by 7")
else:
    print("Not divisible by 3 or 7")