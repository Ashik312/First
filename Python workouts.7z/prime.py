num=int(input("Enter a number :"))
i=0
count=0
if num<=1:
    print("Number cant't be prime")
elif num==2:
    print("Prime")
else:
    for i in range(2,num):
        if num%i==0:
            count=0
            break
        else:
            count=1
    if count==1:
        print("Prime")
    else:
        print("Not prime")