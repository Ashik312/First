# def fact(num):
#     i=1
#     fac=1
#     while i<=num:
#         fac=fac*i
#         i+=1
#     print("Factorial=",fac)

# fact(num=int(input("Enter a number : ")))


# def fact(num):
#     fac=1
#     for i in range(1,num+1):
#         fac=fac*i
#     return fac
# print(fact(5))



num=int(input("Enter a number : "))
i=1
fac=1
while i<=num:
    fac=fac*i
    i+=1
print("Factorial=",fac)