class circle:
    def __init__(self,rad):
        self.rad=rad
    def getarea(self):
        self.area=3.14*self.rad**2
        print("Area = ",self.area)
    def circum(self):
        self.circum=2*3.14*self.rad
        print("circum = ",self.circum)
obj=circle(3)
obj.getarea()
obj.circum()