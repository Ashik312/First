s=3
i=1
sum=0
while i<=s:
    n=int(input("Enter the 1st number : "))
    sum=sum+n
    i+=1
print(sum/s)
