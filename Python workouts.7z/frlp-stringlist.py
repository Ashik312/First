l=["apple","banana","grape"]
for i in l:
    print(i)