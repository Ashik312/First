class student:
    def __init__(self,name,roll):
        self.name=name
        self.roll=roll
    def setage(self):
        self.age=int(input("Enter age :"))
    def setmark(self):
        self.mark=int(input("Enter mark :"))
    def display(self):
        print("Name :",self.name,"\nRoll no :",self.roll,"\nAge :",self.age,"\nMark :",self.mark)
name=input("Enter name :")
roll=int(input("Enter Roll no :"))
sdt1=student(name,roll)
sdt1.setage()
sdt1.setmark()
sdt1.display()
