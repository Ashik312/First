l=[1,3,5,4,7,8]
l1=[1,5,7]
l2=[3,4,8]
l3=[]
ch1=input("Get in to Bank(y/n) :")
if ch1=='y':
    for i in l:
        print(i,end="\t")
    i=0
    while i==2:
        l3.append(int(input("Open one Locker :")))
        if l3[i] in l1:
            print("Locker opened Successfully!!!")
        

