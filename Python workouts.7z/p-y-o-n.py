s=input("Enter a word : ")
s2=""
i=0
while i<len(s):
    if i<2 or i>len(s)-3:
        s2=s2+s[i]
        if i!=len(s)-1:
            s2=s2+"."
    i+=1
print(s2)