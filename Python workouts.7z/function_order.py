def sample():
    print("hello")
def sample1():
    print("world!")
sample1()
sample()

