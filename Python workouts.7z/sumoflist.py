l=[5,10,20,30,50]
i=0
sum=0
while i<len(l):
    sum=sum+l[i]
    i+=1
print(sum)