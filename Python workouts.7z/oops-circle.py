class circle:
    def __init__(self,rad):
        self.rad=rad
    def getarea(self):
        print("Area of Circle :",3.14*(self.rad**2))
    def getcir(self):
        print("Circumference of Circle :",2*3.14*self.rad)
r=int(input("Enter radius :"))
obj1=circle(r)
obj1.getarea()
obj1.getcir()