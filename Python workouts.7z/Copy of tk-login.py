from tkinter import*
root= Tk()
root.title("Login")
root.geometry("500x500")
def cl:
    
btn1=Button(root,text="Switch To Sign up",font=("bold",10)).grid(row=0,column=3,pady=20)
l1=Label(root,text="Login",font=("bold",25)).grid(row=1,column=0,padx=50,pady=30)
l2=Label(root,text="User Name :").grid(row=2,column=0)
e1=Entry(root).grid(row=2,column=1)
l3=Label(root,text="User Name :").grid(row=3,column=0)
e2=Entry(root).grid(row=3,column=1)
btn2=Button(root,text="Login",font=("bold",10)).grid(row=4,column=1,sticky=W)
btn3=Button(root,text="Clear",font=("bold",10),command=cl).grid(row=4,column=1,sticky=E)
root.mainloop()