from tkinter import*
root=Tk()
def new():
    newpanel=Tk()
    newpanel.mainloop
btn=Button(root,text="click me",command=new).grid(row=0,column=4)
root.mainloop()