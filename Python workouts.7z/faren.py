class celfa:
    def __init__(self,cel,faren):
        self.cel=cel
        self.faren=faren
    def Tofaren(self):
        print("26°C = ",(9/5*self.cel)+32,"°F")
    def Tocel(self):
        print("116°F = ",5/9*(self.faren-32),"°C")
c=int(input("Enter celsius : "))
f=int(input("Enter fahrenheit : "))
temp=celfa(c,f)
temp.Tofaren()
temp.Tocel()