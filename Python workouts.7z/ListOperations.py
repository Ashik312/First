def add():
    num=int(input("Enter number to added : "))
    l.append(num)
    print("Modified list : ",l)
def replace():
    pos=int(input("Enter position : "))
    num=int(input("Enter number need to be inserted : "))
    l[pos-1]=num
    print("Modified list : ",l)
def sort():
    print(sorted(l))
def search():
    num=int(input("enter the number to be searched : "))
    if num in l:
        print(num,"is present in the list")
    else:
        print(num,"is not present in the list")


print("Operations\n1.Add/Append\n2.Replace\n3.Sort\n4.Search\n5.Exist")
n=int(input("Enter length of list : "))
print("Enter items : ",end="")
l=[]
for i in range(0,n):
    l.append(int(input()))
print("Entered list : ",l)
while 1==1:
    ch=int(input("Select one of any Operation : "))
    if ch==5:
        break
    elif ch==1:
        add()
    elif ch==2:
        replace()
    elif ch==3:
        sort()
    elif ch==4:
        search()
    else:
        print("Enter a valid number🤫")
