x=int(input("Enter the number two be checked : "))
if x>0:
    print("The number is positive integer")
elif x==0:
    print("The number is neither positive nor negative")
else:
    print("The number is negative integer")
