import re
txt="python is a programming language"
print(re.split("\s",txt))