text="python"
for i in text:
    print(i)