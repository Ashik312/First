dict1={"messi":10,"rono":7,"neymar":11}
list1=sorted(list(dict1.keys()))
list2=sorted(list(dict1.values()))
print("List 1 : ",list1)
print("List 2 : ",list2)
