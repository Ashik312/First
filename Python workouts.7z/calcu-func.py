# def add(a,b):
#     print("value :",a+b)
# def sub(a,b):
#     print("value :",a-b)
# def mul(a,b):
#     print("value :",a*b)
# def div(a,b):
#     print("value :",a/b)


# for i in range(1,100):
    
#     print("1-add\n2-substract\n3-multiply\n4-divide\n5-Exit")
#     ch=int(input("Choose any from above :"))
#     if ch==5:
#         break
#     else:
#         a=int(input("Enter 1st number :"))
#         b=int(input("Enter 2nd number :"))
#         if ch==1:
#             add(a,b)
#         elif ch==2:
#             sub(a,b)
#         elif ch==3:
#             mul(a,b)
#         elif ch==4:
#             div(a,b)
#         else:
#             print("invalid input !")





def add(n,m):
    sum=n+m
    return (sum)
def sub(n,m):
    value=n-m
    return (value)
def mul(n,m):
    product=n*m
    return (product)
def div(n,m):
    value=n/m
    return (value)
i=0
while i!=1:
    
    print("\n list of operations \n1.add\n2.subtraction\n3.multiplication\n4.division\n5.exit")
    ch=int(input("Enter your choice : "))
    if ch==5:
        print("ohh 😒")
        i=1
    else:
        n=int(input("Enter 1st number : "))
        m=int(input("Enter 2nd number : "))
        if ch==1:
            print(add(n,m))
        elif ch==2:
            print(sub(n,m))
        elif ch==3:
            print(mul(n,m))
        elif ch==4:
            print(div(n,m))
        else:
            print("invalid input")