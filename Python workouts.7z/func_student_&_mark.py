def student(name,age,place):
    print(name,age,place)
def marks(Eng,Mal,Math):
    print("English=",Eng,"Malayalam=",Mal,"Maths=",Math)
student("alen",52,"colony")
marks(99,99,99)
print()
student("ashik shonan",99,"Earth")
marks(55,55,55)
print()
student("suneesh",20,"FK")
marks(98,94,88)