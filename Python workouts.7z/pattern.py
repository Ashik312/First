
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(j,end=" ")
#     print()

# for i in range(0,4):
#     print("#"*4)


# y=2
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(y,end=" ")
#         y+=2
#     print()

# y=1
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(y,end=" ")
#         y+=2
#     print()


# x=int(input("Enter a number : "))
# y=
# for i in range(1,x+1):
#     for j in range(1,i+1):
#         print(y,end=" ")
#     print()

# for i in range(1,5):
#     for j in range(1,i+1):
#         if j%2==0:
#             print(end="2 ")
#         else:
#             print(end="1 ")
#     print()












