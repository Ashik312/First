class temp:
    def __init__(self):
        pass
    def tofahren(self):
        self.c=int(input("Enter temperature in Celsius :"))
        print("In Fahrenheit :",(self.c*(9/5))+32)
    def tocelsius(self):
        self.f=int(input("Enter temperature in Fahrenheit :"))
        print("In Fahrenheit :",(5/9)*(self.f-32))
obj1=temp()
print("1.Celsius to Fahreheit\n2.Fahrenheit to Celsius")
ch=int(input("Select one of any :"))
if ch==1:
    obj1.tofahren()
elif ch==2:
    obj1.tocelsius()
else:
    print("Invalid input!")