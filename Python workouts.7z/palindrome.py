l1=input("Enter a word/number :")
j=len(l1)
l2=l1
l1=list(l1)
for i in range(0,j//2):
    j-=1
    ref=l1[i]
    l1[i]=l1[j]
    l1[j]=ref
l1="".join(l1)
if l1==l2:
    print("Palindrome")
else:
    print("Not palindrome")


# x=input("Enter a word : ")
# rev = x[::-1]
# if rev==x:
#     print(x,"is palindrome")
# else:
#     print(x,"is not a palindrome")