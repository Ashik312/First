def kunjappan(x,y,z):
    if x<y and x<z:
        print(x,"is smaller")
    elif y<x and y<z:
        print(y,"is smaller")
    else:
        print(z,"is smaller")
a=int(input("Enter number 1 : "))
b=int(input("Enter number 2 : "))
c=int(input("Enter number 3 : "))
kunjappan(a,b,c)