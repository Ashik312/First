x=input("Enter a number : ")
l=len(x)
sum=0
for i in x:
    sum+=int(i)**l
n=int(x)
if sum==n:
    print("amstrong")
else:
    print("not amstrong")