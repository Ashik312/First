dict1={"number1":2,"number2":22,"number3":5}
l1=dict1.values()
print(sum(l1))