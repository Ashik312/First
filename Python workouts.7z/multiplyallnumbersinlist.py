l=[3,4,6,8]
mul=l[0]*l[1]*l[2]*l[3]
print("product : ",mul)