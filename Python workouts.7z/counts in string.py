x=list("hello world")
le=len(x)
d={}
l2=[]
for i in range(0,le):
    count=0
    for j in range(0,le):
        if x[i]==x[j]:
            count+=1
    if x[i] not in d:
        d[x[i]]=count
print(d)

# x=str(input("Enter the word : "))
# l=[];l1=[];count=0
# for i in x:
#     l.append(i)
# for i in l:
#     count=0
#     for j in l:
#         if i==j:
#             count+=1
#     l1.append(count)
# print(l1)