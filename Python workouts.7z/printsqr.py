num=[1,5,8,11,15,6,4]
for i in num:
    if i>10:continue
    print(i**2)
        
