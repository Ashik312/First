import re
txt=" 1 12 123 1234 12345 234 3455 "
x = re.findall("\d\d\d+", txt)
print(x)